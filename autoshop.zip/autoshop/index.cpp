#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>


#define MAX_LENGTH 100
#define MAX_CARS 100

struct Car {
    int carNumber;
    char model[MAX_LENGTH];
    char mark[MAX_LENGTH];
    char color[MAX_LENGTH];
    float price;
    int horses;
    int quantity;
};


struct User {
    char name[MAX_LENGTH];
    char surname[MAX_LENGTH];
    char email[MAX_LENGTH];
    char login[MAX_LENGTH];
    char password[MAX_LENGTH];
};


void displayAdminMenu() {
    printf("\nAdmin Panel - Choose a command:\n");
    printf("1) See all data\n");
    printf("2) Add a new car\n");
    printf("3) Delete a car\n");
    printf("4) Change data of a car\n");
    printf("0) Exit\n");
}

void viewAllDataWithNumbers(struct Car* cars, int* numCars) {
    printf("\nAll Cars:\n");
    printf("No.\tModel\tMark\tColor\tPrice\tHorses\tQuantity\n");

    FILE* file;
    if (fopen_s(&file, "cars.txt", "r") == 0) {
        printf("File opened successfully.\n");

        char buffer[100];
        while (fgets(buffer, sizeof(buffer), file) != NULL) {
            printf("%s", buffer);
        }

        fclose(file);
    }
    else {
        perror("Unable to open the file for reading");
    }
}

void addNewCar(struct Car** cars, int* numCars) {
    *cars = (struct Car*)realloc(*cars, (*numCars + 1) * sizeof(struct Car));

    if (*cars != NULL) {
        (*cars)[*numCars].carNumber = *numCars + 1;

        printf("Enter car model: ");
        scanf_s("%s", (*cars)[*numCars].model, sizeof((*cars)[*numCars].model));

        printf("Enter car mark: ");
        scanf_s("%s", (*cars)[*numCars].mark, sizeof((*cars)[*numCars].mark));

        printf("Enter car color: ");
        scanf_s("%s", (*cars)[*numCars].color, sizeof((*cars)[*numCars].color));

        printf("Enter car price: ");
        scanf_s("%f", &(*cars)[*numCars].price);

        printf("Enter car horsepower: ");
        scanf_s("%d", &(*cars)[*numCars].horses);

        printf("Enter car quantity: ");
        scanf_s("%d", &(*cars)[*numCars].quantity);

        FILE* file;
        if (fopen_s(&file, "cars.txt", "a") == 0) {
            fprintf(file, "%d\t%s\t%s\t%s\t%.2f\t%d\t%d\n",
                (*cars)[*numCars].carNumber, (*cars)[*numCars].model, (*cars)[*numCars].mark,
                (*cars)[*numCars].color, (*cars)[*numCars].price, (*cars)[*numCars].horses,
                (*cars)[*numCars].quantity);

            fclose(file);
            printf("Car information added successfully.\n");
        }
        else {
            printf("Unable to open the file for writing.\n");
        }

        (*numCars)++;
    }
    else {
        printf("Memory allocation error.\n");
    }
}

void deleteCar(struct Car** cars, int* numCars, int carNumber) {
    if (carNumber >= 1 && carNumber <= *numCars) {
        for (int i = carNumber - 1; i < *numCars - 1; ++i) {
            (*cars)[i] = (*cars)[i + 1];
            (*cars)[i].carNumber = (*cars)[i].carNumber - 1;
        }

        (*numCars)--;

        FILE* file;
        if (fopen_s(&file, "cars.txt", "w") == 0) {
            for (int i = 0; i < *numCars; ++i) {
                fprintf(file, "%d\t%s\t%s\t%s\t%.2f\t%d\t%d\n",
                    (*cars)[i].carNumber, (*cars)[i].model, (*cars)[i].mark,
                    (*cars)[i].color, (*cars)[i].price, (*cars)[i].horses,
                    (*cars)[i].quantity);
            }

            fclose(file);
            printf("Car information deleted successfully.\n");
        }
        else {
            printf("Unable to open the file for writing.\n");
        }
    }
    else {
        printf("Invalid car number. No changes made.\n");
    }
}

void changeCarData(struct Car** cars, int numCars, int carNumber) {
    if (carNumber >= 1 && carNumber <= numCars) {
        printf("\nCurrent data of Car %d:\n", carNumber);
        printf("Model: %s\n", (*cars)[carNumber - 1].model);
        printf("Mark: %s\n", (*cars)[carNumber - 1].mark);
        printf("Color: %s\n", (*cars)[carNumber - 1].color);
        printf("Price: %.2f\n", (*cars)[carNumber - 1].price);
        printf("Horses: %d\n", (*cars)[carNumber - 1].horses);
        printf("Quantity: %d\n", (*cars)[carNumber - 1].quantity);

        printf("\nEnter new data for Car %d:\n", carNumber);
        printf("Enter car model: ");
        scanf_s("%s", (*cars)[carNumber - 1].model, sizeof((*cars)[carNumber - 1].model));

        printf("Enter car mark: ");
        scanf_s("%s", (*cars)[carNumber - 1].mark, sizeof((*cars)[carNumber - 1].mark));

        printf("Enter car color: ");
        scanf_s("%s", (*cars)[carNumber - 1].color, sizeof((*cars)[carNumber - 1].color));

        printf("Enter car price: ");
        scanf_s("%f", &(*cars)[carNumber - 1].price);

        printf("Enter car horses: ");
        scanf_s("%d", &(*cars)[carNumber - 1].horses);

        printf("Enter car quantity: ");
        scanf_s("%d", &(*cars)[carNumber - 1].quantity);


        FILE* file;
        if (fopen_s(&file, "cars.txt", "w") == 0) {
            for (int i = 0; i < numCars; ++i) {
                fprintf(file, "%d\t%s\t%s\t%s\t%.2f\t%d\t%d\n",
                    i + 1, (*cars)[i].model, (*cars)[i].mark,
                    (*cars)[i].color, (*cars)[i].price, (*cars)[i].horses,
                    (*cars)[i].quantity);
            }

            fclose(file);
            printf("Car information changed successfully.\n");

            printf("\nUpdated data of Car %d:\n", carNumber);
            printf("Model: %s\n", (*cars)[carNumber - 1].model);
            printf("Mark: %s\n", (*cars)[carNumber - 1].mark);
            printf("Color: %s\n", (*cars)[carNumber - 1].color);
            printf("Price: %.2f\n", (*cars)[carNumber - 1].price);
            printf("Horses: %d\n", (*cars)[carNumber - 1].horses);
            printf("Quantity: %d\n", (*cars)[carNumber - 1].quantity);
        }
        else {
            printf("Unable to open the file for writing.\n");
        }
    }
    else {
        printf("Invalid car number. No changes made.\n");
    }
}


void handleAdminPanel() {
    char adminLogin[MAX_LENGTH];
    char adminPassword[MAX_LENGTH];

    printf("Enter admin login: ");
    scanf_s("%s", adminLogin, sizeof(adminLogin));

    printf("Enter admin password: ");
    scanf_s("%s", adminPassword, sizeof(adminPassword));

    if (strcmp(adminLogin, "admin") == 0 && strcmp(adminPassword, "12345678") == 0) {
        printf("Welcome, Admin Panel!\n");

        struct Car* cars = NULL;
        int numCars = 0;

        FILE* file;
        if (fopen_s(&file, "cars.txt", "r") == 0) {
            while (fscanf_s(file, "%*d%*[^\n]") != EOF) {
                numCars++;
            }

            fclose(file);
        }

        cars = (struct Car*)malloc(numCars * sizeof(struct Car));

        if (fopen_s(&file, "cars.txt", "r") == 0) {
            for (int i = 0; i < numCars; ++i) {
                fscanf_s(file, "%d %s %s %s %f %d %d",
                    &cars[i].carNumber, cars[i].model, sizeof(cars[i].model),
                    cars[i].mark, sizeof(cars[i].mark),
                    cars[i].color, sizeof(cars[i].color),
                    &cars[i].price, &cars[i].horses, &cars[i].quantity);
            }

            fclose(file);
        }

        int choice;
        do {
            displayAdminMenu();
            printf("Enter your choice: ");
            scanf_s("%d", &choice);

            switch (choice) {
            case 1:
                viewAllDataWithNumbers(cars, &numCars);
                break;
            case 2:
                addNewCar(&cars, &numCars);
                break;
            case 3:
                viewAllDataWithNumbers(cars, &numCars);
                int carNumber;
                printf("Enter the number of the car to delete: ");
                scanf_s("%d", &carNumber);
                deleteCar(&cars, &numCars, carNumber);
                break;
            case 4:
                viewAllDataWithNumbers(cars, &numCars);
                int carToChange;
                printf("Enter the number of the car to change data: ");
                scanf_s("%d", &carToChange);
                changeCarData(&cars, numCars, carToChange);
                break;
            case 0:
                printf("Exiting admin panel.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
            }
        } while (choice != 0);

        free(cars);
    }
    else {
        printf("Incorrect admin login or password.\n");
    }
}


void displayUserMenu() {
    printf("\nUser Panel - Choose a command:\n");
    printf("1) See all products\n");
    printf("2) Find by mark\n");
    printf("3) Find by model\n");
    printf("4) Find by minimum and maximum prices\n");
    printf("0) Exit\n");
}


void displayCarsFromFile() {
    FILE* file = fopen("cars.txt", "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    printf("\nAll Cars:\n");
    printf("No.\tModel\tMark\tColor\tPrice\tHorses\tQuantity\n");

    FILE* file2;
    if (fopen_s(&file2, "cars.txt", "r") == 0) {
        printf("File opened successfully.\n");

        char buffer[100];
        while (fgets(buffer, sizeof(buffer), file2) != NULL) {
            printf("%s", buffer);
        }

        fclose(file2);
    }
    else {
        perror("Unable to open the file for reading");
    }
}

void findCarsByPriceRange(float minPrice, float maxPrice) {
    FILE* file = fopen("cars.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return;
    }

    struct Car cars[MAX_CARS];
    int numCars = 0;

    while (fscanf(file, "%d %s %s %s %f %d %d",
        &cars[numCars].carNumber,
        cars[numCars].model,
        cars[numCars].mark,
        cars[numCars].color,
        &cars[numCars].price,
        &cars[numCars].horses,
        &cars[numCars].quantity) == 7) {
        numCars++;
        if (numCars >= MAX_CARS) {
            break;
        }
    }

    fclose(file);

    printf("Cars within the price range $%.2f - $%.2f:\n", minPrice, maxPrice);
    for (int i = 0; i < numCars; ++i) {
        if (cars[i].price >= minPrice && cars[i].price <= maxPrice) {
            printf("Car Number: %d\n", cars[i].carNumber);
            printf("Model: %s\n", cars[i].model);
            printf("Mark: %s\n", cars[i].mark);
            printf("Color: %s\n", cars[i].color);
            printf("Price: %.2f\n", cars[i].price);
            printf("Horses: %d\n", cars[i].horses);
            printf("Quantity: %d\n", cars[i].quantity);
            printf("--------------------------\n");
        }
    }
}

void findCarsByMark(const char* mark) {
    FILE* file = fopen("cars.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return;
    }

    struct Car cars[MAX_CARS];
    int numCars = 0;

    while (fscanf(file, "%d %s %s %s %f %d %d",
        &cars[numCars].carNumber,
        cars[numCars].model,
        cars[numCars].mark,
        cars[numCars].color,
        &cars[numCars].price,
        &cars[numCars].horses,
        &cars[numCars].quantity) == 7) {
        numCars++;
        if (numCars >= MAX_CARS) {
            break;
        }
    }

    fclose(file);

    printf("Cars with mark '%s':\n", mark);
    for (int i = 0; i < numCars; ++i) {
        if (strcmp(cars[i].mark, mark) == 0) {
            printf("Car Number: %d\n", cars[i].carNumber);
            printf("Model: %s\n", cars[i].model);
            printf("Mark: %s\n", cars[i].mark);
            printf("Color: %s\n", cars[i].color);
            printf("Price: %.2f\n", cars[i].price);
            printf("Horses: %d\n", cars[i].horses);
            printf("Quantity: %d\n", cars[i].quantity);
            printf("--------------------------\n");
        }
    }
}

void findCarsByModel(const char* model) {
    FILE* file = fopen("cars.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return;
    }

    struct Car cars[MAX_CARS];
    int numCars = 0;

    while (fscanf(file, "%d %s %s %s %f %d %d",
        &cars[numCars].carNumber,
        cars[numCars].model,
        cars[numCars].mark,
        cars[numCars].color,
        &cars[numCars].price,
        &cars[numCars].horses,
        &cars[numCars].quantity) == 7) {
        numCars++;
        if (numCars >= MAX_CARS) {
            break;
        }
    }

    fclose(file);

    printf("Cars with model '%s':\n", model);
    for (int i = 0; i < numCars; ++i) {
        if (strcmp(cars[i].model, model) == 0) {
            printf("Car Number: %d\n", cars[i].carNumber);
            printf("Model: %s\n", cars[i].model);
            printf("Mark: %s\n", cars[i].mark);
            printf("Color: %s\n", cars[i].color);
            printf("Price: %.2f\n", cars[i].price);
            printf("Horses: %d\n", cars[i].horses);
            printf("Quantity: %d\n", cars[i].quantity);
            printf("--------------------------\n");
        }
    }
}

void buyCar(int carNum) {
    FILE* file = fopen("cars.txt", "r+");
    if (file == NULL) {
        printf("Error opening file.\n");
        return;
    }

    struct Car car;
    int found = 0;
    long int pos = 0;

    while (fscanf(file, "%d %s %s %s %f %d %d",
        &car.carNumber,
        car.model,
        car.mark,
        car.color,
        &car.price,
        &car.horses,
        &car.quantity) == 7) {

        if (car.carNumber == carNum) {
            found = 1;
            pos = ftell(file) - (sizeof(struct Car) * 1);

            if (car.quantity > 0) {
                printf("You bought the following car:\n");
                printf("Car Number: %d\n", car.carNumber);
                printf("Model: %s\n", car.model);
                printf("Mark: %s\n", car.mark);
                printf("Color: %s\n", car.color);
                printf("Price: %.2f\n", car.price);
                printf("Horses: %d\n", car.horses);
                printf("Quantity before purchase: %d\n", car.quantity);
                car.quantity--;
                printf("Remaining quantity after purchase: %d\n", car.quantity);

                fseek(file, pos, SEEK_SET);
                fprintf(file, "%d %s %s %s %.2f %d %d\n",
                    car.carNumber,
                    car.model,
                    car.mark,
                    car.color,
                    car.price,
                    car.horses,
                    car.quantity);
            }
            else {
                printf("Sorry, this car is out of stock.\n");
            }

            break;
        }
    }

    if (!found) {
        printf("Car with number %d not found.\n", carNum);
    }

    fclose(file);
}


void handleUserPanel(const struct User* currentUser) {
    int choiceUser;
    printf("Welcome, %s %s!\n", currentUser->name, currentUser->surname);
    printf("Email: %s\n", currentUser->email);
    printf("Login: %s\n", currentUser->login);

    do {
        displayUserMenu();
        printf("Enter your choice: ");
        scanf("%d", &choiceUser);
        int carNumber;

        getchar();

        switch (choiceUser) {
        case 0:
            printf("Exiting...\n");
            break;
        case 1:
            displayCarsFromFile();
            printf("Which car do you want to buy? Enter the car number: ");
            scanf("%d", &carNumber);
            buyCar(carNumber);
            break;

        case 2: {
            char mark[MAX_LENGTH];
            printf("Enter the mark: ");
            scanf("%s", mark);
            findCarsByMark(mark);
            printf("Which car do you want to buy? Enter the car number: ");
            scanf("%d", &carNumber);
            buyCar(carNumber);
            break;
        }
        case 3: {
            char model[MAX_LENGTH];
            printf("Enter the model: ");
            scanf("%s", model);
            findCarsByModel(model);
            printf("Which car do you want to buy? Enter the car number: ");
            scanf("%d", &carNumber);
            buyCar(carNumber);
            break;
        }
        case 4: {
            float minPrice, maxPrice;
            printf("Enter minimum price: ");
            scanf("%f", &minPrice);
            printf("Enter maximum price: ");
            scanf("%f", &maxPrice);

            findCarsByPriceRange(minPrice, maxPrice);
            printf("Which car do you want to buy? Enter the car number: ");
            scanf("%d", &carNumber);
            buyCar(carNumber);
            break;
        }
        default:
            printf("Invalid choice. Please select a valid option.\n");
            break;
        }
    } while (choiceUser != 0);
}


int isLoginUnique(const char* login) {
    FILE* userFile;
    if (fopen_s(&userFile, "users.txt", "r") == 0) {
        char fileLogin[MAX_LENGTH];
        char filePassword[MAX_LENGTH];

        while (fscanf_s(userFile, "%s %s %*s %*s %*s", fileLogin, sizeof(fileLogin), filePassword, sizeof(filePassword)) != EOF) {
            if (strcmp(login, fileLogin) == 0) {
                fclose(userFile);
                return 0;
            }
        }

        fclose(userFile);
    }
    return 1;
}
void registerUser(struct User* newUser) {
    printf("Welcome to AutoShop's registration form!\n");
    printf("Enter your name: ");
    fgets(newUser->name, sizeof(newUser->name), stdin);
    newUser->name[strcspn(newUser->name, "\n")] = '\0';

    printf("Enter your surname: ");
    fgets(newUser->surname, sizeof(newUser->surname), stdin);
    newUser->surname[strcspn(newUser->surname, "\n")] = '\0';

    printf("Enter your email: ");
    fgets(newUser->email, sizeof(newUser->email), stdin);
    newUser->email[strcspn(newUser->email, "\n")] = '\0';

    // Ensure a unique login
    do {
        printf("Enter your login: ");
        fgets(newUser->login, sizeof(newUser->login), stdin);
        newUser->login[strcspn(newUser->login, "\n")] = '\0';

        if (!isLoginUnique(newUser->login)) {
            printf("Error: Login already exists. Please choose a different login.\n");
        }
    } while (!isLoginUnique(newUser->login));

    printf("Enter your password: ");
    fgets(newUser->password, sizeof(newUser->password), stdin);
    newUser->password[strcspn(newUser->password, "\n")] = '\0';


    FILE* userFile;
    if (fopen_s(&userFile, "users.txt", "a") == 0) {
        fprintf(userFile, "%s %s %s %s %s\n",
            newUser->name, newUser->surname, newUser->email, newUser->login, newUser->password);

        fclose(userFile);
        printf("Registration successful!\n");
        handleUserPanel(newUser);
    }
    else {
        printf("Unable to open the file for writing.\n");
    }

}

int loginUser(struct User* currentUser) {
    printf("Enter your login: ");
    fgets(currentUser->login, sizeof(currentUser->login), stdin);
    currentUser->login[strcspn(currentUser->login, "\n")] = '\0';

    printf("Enter your password: ");
    fgets(currentUser->password, sizeof(currentUser->password), stdin);
    currentUser->password[strcspn(currentUser->password, "\n")] = '\0';

    FILE* userFile;
    if (fopen_s(&userFile, "users.txt", "r") == 0) {
        char fileLine[MAX_LENGTH];

        while (fgets(fileLine, sizeof(fileLine), userFile) != NULL) {
            char fileLogin[MAX_LENGTH];
            char filePassword[MAX_LENGTH];

            if (sscanf(fileLine, "%*s %*s %*s %s %s", fileLogin, filePassword) == 2) {
                if (strcmp(currentUser->login, fileLogin) == 0 && strcmp(currentUser->password, filePassword) == 0) {
                    fclose(userFile);
                    return 1;
                }
            }
        }

        fclose(userFile);
    }

    return 0;
}


int main() {
    printf("Welcome to Autoshop!\n");

    char userType[MAX_LENGTH];
    printf("Are you admin or user? ");
    fgets(userType, sizeof(userType), stdin);
    userType[strcspn(userType, "\n")] = '\0';

    if (strcmp(userType, "admin") == 0) {
        handleAdminPanel();
    }
    else if (strcmp(userType, "user") == 0) {
        struct User currentUser;

        char isRegistered[MAX_LENGTH];
        printf("Are you registered? (yes/no) ");
        fgets(isRegistered, sizeof(isRegistered), stdin);
        isRegistered[strcspn(isRegistered, "\n")] = '\0';

        if (strcmp(isRegistered, "no") == 0) {
            registerUser(&currentUser);
            displayUserMenu();
            handleUserPanel(&currentUser);
        }
        else if (strcmp(isRegistered, "yes") == 0) {
            struct User loggedInUser;
            int loginSuccess = loginUser(&loggedInUser);

            if (loginSuccess) {
                printf("Login successful!\n");
                handleUserPanel(&loggedInUser);
            }
            else {
                printf("Invalid login credentials.\n");
            }
        }
        else {
            printf("Invalid response. Please enter 'yes' or 'no'.\n");
        }
    }

    return 0;
}